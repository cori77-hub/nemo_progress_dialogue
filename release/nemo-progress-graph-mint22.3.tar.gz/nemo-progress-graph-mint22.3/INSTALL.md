# Nemo Progress Graph — Mint 22.3 Package

## Quick Install (prebuilt .deb)

```bash
cd deb
sudo dpkg -i nemo_6.6.3+zena_amd64.deb nemo-data_6.6.3+zena_all.deb libnemo-extension1_6.6.3+zena_amd64.deb gir1.2-nemo-3.0_6.6.3+zena_amd64.deb
sudo apt-get install -f
nemo -q && nemo
```

## Install via Script (backs up originals first)

```bash
./manage-nemo-patch.sh install
nemo -q && nemo
```

## Uninstall / Restore Originals

```bash
./manage-nemo-patch.sh uninstall
nemo -q && nemo
```

## Build from Source

See README.md for full build instructions.

## Contents

| Path | Description |
|------|-------------|
| `deb/` | Prebuilt .deb packages for Mint 22.3 / Nemo 6.6.3+zena |
| `patched/` | Patched source files ready to drop into nemo-6.6.3+zena source tree |
| `diffs/` | Clean diffs against original Mint 22.3 Nemo sources |
| `manage-nemo-patch.sh` | Install/uninstall/restore management script |
| `README.md` | Full documentation with credits and build instructions |

## Credits

**Original author:** Mario Lohajner ([@mlohajner](https://github.com/mlohajner))
**Mint 22.3 port:** Daniel ([@cori77-hub](https://github.com/cori77-hub))

## License

GPL-2.0+ (same as Nemo)